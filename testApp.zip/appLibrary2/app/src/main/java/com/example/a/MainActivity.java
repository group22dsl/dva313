//CODE BY VICTOR AND LOUIS

package com.example.a;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.mylibrary.Analytics;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private String[] Tags = {"Crash", "supprise!"};
    private String[] Info = {"PID: 6502 crash", "EE: 1101 started engine without controll", "Det är en fin bil", "Är typ grym!"};
    private Random Rand = new Random();
    private String Prio;
    List<String> categories = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Using our library here by making the SendHelper:
        Analytics sender = new Analytics(this);
        setContentView(R.layout.activity_main);
        setTitle("Test app");


        //BTN THAT RUNS THE SEND FUNCTION
        Button sendBtn = (Button) findViewById(R.id.sendBtn);
        Button sendCustomBtn = (Button) findViewById(R.id.CustomSendButton);
        EditText tagsText = (EditText) findViewById(R.id.TagsText);
        EditText idText = (EditText) findViewById(R.id.IDText);
        EditText dataText = (EditText) findViewById(R.id.DataText);
        categories.add("Choose Priority");
        categories.add("Critical");
        categories.add("High");
        categories.add("Medium");
        categories.add("Low");
        Spinner spinner = findViewById(R.id.spinner);
        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sender.sendCriticalPriority(Tags, Info[Rand.nextInt(4)]);
            }
        });
        sendCustomBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] array = tagsText.getText().toString().split(",");
                if(Prio.equals("Choose Priority") || Prio.equals("null")){
                    Toast.makeText(getApplicationContext(),"Please select a valid priority",Toast.LENGTH_LONG).show();
                }else{
                    sender.sendDebugMessage(Prio, array, idText.getText().toString(), dataText.getText().toString());
                }

            }
        });


        ArrayAdapter<String> dataAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, categories);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    String item = adapterView.getItemAtPosition(i).toString();
                    Prio = item;
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }
}