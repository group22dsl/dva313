package com.example.mylibrary;

import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Analytics {
    private String ID;
    private Context context;
    private Intent intent = new Intent("testData");
    private enum Priority {Critical, High, Medium, Low}

    public Analytics(Context context){
        this.context = context;
        ID = context.getPackageName();
    }

    private void sendMessage(Priority priority, String[] tags, String data){
        JSONObject jsonObject = parser(priority, tags, ID, data);
        intent.putExtra("data", jsonObject.toString());
        context.sendBroadcast(intent);
    }

    public void sendDebugMessage(String priority, String[] tags, String id, String data){
        //TODO assert string value exist in Priority enum.
        //TODO crashes if values are null!
        Priority prio = Priority.valueOf(priority);
        JSONObject jsonObject = parser(prio, tags, id, data);
        intent.putExtra("data", jsonObject.toString());
        context.sendBroadcast(intent);
    }

    private JSONObject parser(Priority priority, String[] tags, String id, String data){
        String date = String.valueOf(Calendar.getInstance().getTime());
        JSONObject jsonObject = new JSONObject();
        JSONArray tagArray = new JSONArray();
        for(int i = 0; i < tags.length; i++){
            tagArray.put(tags[i]);
        }
        try {
            jsonObject.put("Priority", priority);
            //We use our function here to turn the given string to an actual date.
            jsonObject.put("Tags",tagArray);
            jsonObject.put("ID", id);
            //jsonObject.put("Date",convertToDate(Date));
            jsonObject.put("Date", date);
            jsonObject.put("Data",data);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonObject;
    }

    public void sendLowPriority(String[] tags, String data){
        sendMessage(Priority.Low, tags, data);
    }

    public void sendMediumPriority(String[] tags, String data){
        sendMessage(Priority.Medium, tags, data);
    }

    public void sendHighPriority(String[] tags, String data){
        sendMessage(Priority.High, tags, data);
    }

    public void sendCriticalPriority(String[] tags, String data){
        sendMessage(Priority.Critical, tags, data);
    }

    /*private String convertToDate(String stringDate) {
        Date date = new Date(Long.parseLong(stringDate));
        //We return a SimpleDateFormat object with the date variable on line 38.
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);
    }*/
}
